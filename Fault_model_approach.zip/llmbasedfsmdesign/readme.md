# nl2fsm: Designing FSMs Specifications from Requirements with GPT-4.0

The repo contain python code implementing and evaluating a method
of designing formal specifications finite states machines from their
requirements expressed in English


## Description
The code allows 
* generating simulated data. The data include requirements and finite states machines
* prompting GPT-4.0 (you need a paid key for OpenAI API) for automatic generation of finites states machines (FSM) from their textual description
* evaluating the correctness of the generated FSM 
* automatic building of a repair domain
* semi-automatic repair of the generated FSM using the fault domain and expert knowledge. Three other repair methods are implemented  at https://github.com/PaulRCh/nl2fsm. The code share the same data structure for mealy machines.


In the current implementation expert-knowledge is mimicked by another finite state machine called an oracle.
The code also provide useful data structures and algorithms for reasoning on finite states. For example, it provides
a function for computing the distinguishing product of two FSM.

The specification are input complete and deterministic FSM.

Interested user can set the seed at adequate line of code of the module ramdom wherever the same data are needed.
This setting is particularly important with the datagenerator packages and module.

The folder evaluationlogdata4paper contains samples of data produce in evaluating the design method.


## Getting Started

### Dependencies

* python-SAT (glucose or an increment sat solver)
* OpenAI

### Installing

* clone the repo
* make sure the dependencies are installed
* open the projet with your favorite dev tool
* provide an OpenAI key in modules in the  package llmprompting 

### Executing program

* consider the package benchmarksllmbaseddesign and execute the module benchmarksbase.
* You can set the number of state of the generated oracle and the number of oracle and description that should be created for the evaluation of the approach.Som folder in this package contains example of simulated data.


## Help

If you have any questions, feel free to send me an email.

## Authors

## Version History


## License


## Acknowledgments
- The authors thank their collaborators. 
