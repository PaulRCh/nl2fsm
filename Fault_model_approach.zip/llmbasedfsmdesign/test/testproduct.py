from mealymachinemodel import distinguishingproduct
from generatorsimulateddata import generatorexample
from utils import affichage

if __name__ == "__main__":
    mm1= generatorexample.build_machine1()
    affichage.show_mealy_machine(mm1)
    mm2= generatorexample.build_machine2()
    affichage.show_mealy_machine(mm2)
    produit = distinguishingproduct.ProductMealyMachine(mm1,mm2)
    produit.make_product()
    affichage.show_mealy_machine(produit)
    iseq, path = produit.find_a_path_to_diff_state()
    print(iseq, path)
