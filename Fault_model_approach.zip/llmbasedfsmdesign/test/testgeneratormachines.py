from generatorsimulateddata import generatormealymachine
from utils import affichage

if __name__ == "__main__":
    ia =['a','b']
    oa =['0','1']
    oracle = generatormealymachine.generateinputcompletemm(ia, oa, 4)
    affichage.show_mealy_machine(oracle)
    mutationmachine = generatormealymachine.generatemutationmachine(oracle, 3, "mm" + oracle.get_name())
    print(mutationmachine.toDot())
    affichage.show_mealy_machine(mutationmachine)
