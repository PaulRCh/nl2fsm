from miningdfsmfromrepairdomain import miningbasic
from utils import affichage
from generatorsimulateddata import generatorexample


if __name__ == "__main__":
    ia =['a','b']
    oa =['0','1']
    oracle, mutationmachine = generatorexample.generate_mutationmachinewithoracle()
    affichage.show_mealy_machine(oracle)
    affichage.show_mealy_machine(mutationmachine)
    expectedoracle, testsuite = miningbasic.mining(mutationmachine, oracle)
    affichage.show_mealy_machine(expectedoracle)
    print(testsuite)
