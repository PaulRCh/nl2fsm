from utils import affichage
from generatorsimulateddata import generatorexample



if __name__ == "__main__":
    mm1= generatorexample.build_oracle()
    print(mm1.toDot())
    affichage.show_mealy_machine(mm1)
    iseq = []
    iseq.append('a')
    iseq.append('b')
    oseq, path = mm1.computeanouputsequence(iseq)
    print(oseq)
    print(path)
    oracle = generatorexample.build_machine2()
    rst = oracle.isComplete()
    print(rst)


