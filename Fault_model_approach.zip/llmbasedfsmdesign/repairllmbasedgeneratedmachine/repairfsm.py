from mealymachinemodel import mealymachine
from miningdfsmfromrepairdomain import miningbasic
from generatorsimulateddata import generatorrepairdomain

MAX_ATTEMPT = 30


def syntaxrepair(oracle,generatedspec,difftransitions,session) :
    return None

def distsequencerepair(oracle,generatedspec,product,session) :
    return None

def checksequencerepair(oracle,generatedspec,product,session):
    return None

def faultbasedrepair(oracle:mealymachine.MealyMachine, generatedspec:mealymachine.MealyMachine, difftransitions, product:mealymachine.MealyMachine, session)-> (mealymachine.MealyMachine, list[list], list, mealymachine.MealyMachine):
    addtransitions =[]
    repairdomain = generatorrepairdomain.buildrepairdomain(generatedspec)
    addtransitions = generatorrepairdomain.addoracleinmutationmachine(repairdomain,oracle)
    extractedFsm, testsuite = miningbasic.mining(repairdomain,oracle)
    return extractedFsm, testsuite, addtransitions, repairdomain
