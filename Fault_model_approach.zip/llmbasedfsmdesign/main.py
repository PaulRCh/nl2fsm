#consider the module benchmarkbase in package benchmarksllmbaseddesign
#The module allow performing the evaluation of the FSM design method
#that uses fault repair domain
