import openai._client
from openai import OpenAI

API_KEY = "provide your key"
class SessionLLM(object) :
    _id_next_query :int
    _client : None
    _system_msg:str
    _conversation_history =list
    def __init__(self):
        self._id_next_query =0
        self._client = OpenAI(api_key=API_KEY)
        self._system_msg = "As an assistant, you know dot format for representing graph. You known about reactive systems modelling. " \
                      " Reactive systems  produce an output and performs transtition from a source state to a target state on occurence of an input"\
                      "You represent a transition in the format :  source input/output target " \
                       "You are skilled in translating requirements of reactive systems to Mealy machine."\
                      "you only enumerate the transitions starting in a new line in your response"\
                      " "
        self._assistant_history=[]
        self._prompt_history=[]
        self._conversation_history = [{"role": "system", "content": self._system_msg}]

    def query(self, user_prompt):
        self._conversation_history.append({"role": "user", "content": user_prompt})

        # Generate a response using the OpenAI API
        response = self._client.chat.completions.create(
                model= "gpt-4o-mini", #"gpt-3.5-turbo", #
                messages= self._conversation_history,
                max_tokens= 800,
                n= 1,
                stop= None,
                temperature =  0.0,
                top_p = 1.0,
                frequency_penalty = 0.0,
                presence_penalty= 0.0
            )

        # Extract the assistant's response
        assistant_response = response.choices[0].message.content.strip()
        # Append assistant response to the conversation history
        self._conversation_history.append({"role": "assistant", "content": assistant_response})
        self._id_next_query+=1
        return assistant_response

    def recopie(self):
        rst = SessionLLM()
        rst._conversation_history= self._conversation_history.copy()
        rst._client =  OpenAI(api_key="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")
        rst._system_msg = self._system_msg
        rst._assistant_history=self._assistant_history.copy()
        rst._prompt_history=self._prompt_history.copy()
        return rst
