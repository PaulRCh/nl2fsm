from openai import OpenAI

API_KEY ="Provide-you_key-here"
client = OpenAI(api_key=API_KEY)

# Initialize conversation history
system_msg_original = "As an assistant, you know dot format for representing graph. You known about reactive systems modelling. " \
                      " Reactive systems  produce an output and performs transtition from a source state to a target state on occurence of an input"\
                      "You represent a transition in the format :  source input/output target " \
                       "You are skilled in translating requirements of reactive systems to Mealy machine."\
                      "you only enumerate the transitions starting in a new line in your response"\
                      " "

conversation_history = [
    {"role": "system", "content": system_msg_original}
]



def generate_response(user_input):
    # Append user input to conversation history
    conversation_history.append({"role": "user", "content": user_input})

    # Generate a response using the OpenAI API
    response = client.chat.completions.create(
                model= "gpt-4o-mini", #"gpt-3.5-turbo", #
                messages= conversation_history,
                max_tokens= 800,
                n= 1,
                stop= None,
                temperature =  0.0,
                top_p = 1.0,
                frequency_penalty = 0.0,
                presence_penalty= 0.0
    )

    # Extract the assistant's response
    assistant_response = response.choices[0].message.content.strip()


    # Append assistant response to the conversation history
    #conversation_history.append({"role": "assistant", "content": assistant_response})

    return assistant_response


if __name__=="__main__" :
    # Example usage
    user_input = "Can you translate the following requirement :"\
                  "when the system is in s1 , 0 is produced and the system reaches s3 if  a occurs."\
                  "the output 1 is produced and s5 is reached if the input is b from s1."\
                  "the system produces 1 and s2 is reached on occurence of input b from state s3."\
                  "when the system is in state s3 , 1 is produced and s4 is reached if the input a occurs."\
                  "the output 0 is produced and state s6 is reached if  a occurs from s2."\
                  "when it is in state s2 the application returns 1 and s2 is reached if the input is b."\
                  "from state state s4 , 1 is produced and the system reaches state s4 on occurence of input a."\
                  "from state s5 , 1 is produced and it moves to s2 on occurence of input a."\
                  "from state s4 , 1 is returned and s3 is reached on occurence of input b."\
                  "in  state s6 the application produces 0 and the system moves to state s6 if the input b occurs."\
                 "the application returns 1 and it moves to s3 if  a occurs from s6."\
                 "from state s5 , 1 is produced and it moves to state s6 if the input b occurs."

    response = generate_response(user_input)

    print(f"Assistant: {response}")

    # Simulate another user input
    #user_input = "in the graphviz format"
    #response = generate_response(user_input)
    #print(f"Assistant: {response}")
