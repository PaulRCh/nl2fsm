from mealymachinemodel import mealymachine

def make_transition_prompt(tr:mealymachine.Transition) :
    pass

def make_description_prompt(description)->str:
    return f'{description}. Can you translate this requirement ?'
