from mealymachinemodel import mealymachine
from miningdfsmfromrepairdomain import miningbasic

def build_oracle() -> mealymachine.MealyMachine :
    ia =('a','b')
    oa =('0','1')
    nbetats = 4
    mm = mealymachine.MealyMachine(ia,oa,'oracle')
    e = []
    for i in range(1,nbetats+1) :
        e.append(mm.add_state(mealymachine.State(f"s{i}")))

    mm.set_initial_state(e[0].get_id())

    mm.add_transition(e[0].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[0].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[0].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[2].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[3].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[2].get_id())
    mm.add_transition(e[3].get_id(),mm.input_alphabet[0],mm.output_alphabet[1],e[0].get_id())
    mm.add_transition(e[3].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[3].get_id())
    return mm

def build_generated() -> mealymachine.MealyMachine :
    ia =('a','b')
    oa =('0','1')
    nbetats = 4
    mm = mealymachine.MealyMachine(ia,oa,'generated')
    e = []
    for i in range(1,nbetats+1) :
        e.append(mm.add_state(mealymachine.State(f"s{i}")))

    mm.set_initial_state(e[0].get_id())

    mm.add_transition(e[0].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[0].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[0].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[0],mm.output_alphabet[1],e[2].get_id())
    #mm.add_transition(e[1].get_id(),mm.input_alphabet[1],mm.output_alphabet[1],e[1].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[3].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[2].get_id())
    #mm.add_transition(e[3].get_id(),mm.input_alphabet[0],mm.output_alphabet[1],e[0].get_id())
    mm.add_transition(e[3].get_id(),mm.input_alphabet[1],mm.output_alphabet[1],e[3].get_id())
    return mm

def example_mutationmachine() -> (mealymachine.MealyMachine,list) :
    ia =('a','b')
    oa =('0','1')
    nbetats = 4
    mm = mealymachine.MealyMachine(ia,oa,'mutationmachine')
    e = []
    for i in range(1,nbetats+1) :
        e.append(mm.add_state(mealymachine.State(f"s{i}")))

    mm.set_initial_state(e[0].get_id())
    oracletransitionidlist =[]

    mm.add_transition(e[0].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[1].get_id(),1)
    mm.add_transition(e[0].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[0].get_id(),2)
    oracletransitionidlist.extend([1,2])
    mm.add_transition(e[1].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[2].get_id(),3)
    mm.add_transition(e[1].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[1].get_id(),4)
    oracletransitionidlist.extend([3,4])
    mm.add_transition(e[2].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[3].get_id(),5)
    mm.add_transition(e[2].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[2].get_id(),6)
    mm.add_transition(e[2].get_id(),mm.input_alphabet[0],mm.output_alphabet[1],e[2].get_id(),7)
    mm.add_transition(e[2].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[2].get_id(),8)
    oracletransitionidlist.extend([5,8])
    mm.add_transition(e[3].get_id(),mm.input_alphabet[0],mm.output_alphabet[1],e[0].get_id(),9)
    mm.add_transition(e[3].get_id(),mm.input_alphabet[0],mm.output_alphabet[1],e[1].get_id(),10)
    mm.add_transition(e[3].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[3].get_id(),11)
    oracletransitionidlist.extend([11,9])
    return mm,oracletransitionidlist



def example_oracle() -> mealymachine.MealyMachine :
    ia =('a','b')
    oa =('0','1')
    nbetats = 4
    mm = mealymachine.MealyMachine(ia,oa,'oracle')
    e = []
    for i in range(1,nbetats+1) :
        e.append(mm.add_state(mealymachine.State(f"s{i}")))

    mm.set_initial_state(e[0].get_id())

    mm.add_transition(e[0].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[0].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[0].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[2].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[3].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[2].get_id())
    mm.add_transition(e[3].get_id(),mm.input_alphabet[0],mm.output_alphabet[1],e[0].get_id())
    mm.add_transition(e[3].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[3].get_id())
    return mm

def build_machine1() -> mealymachine.MealyMachine :
    ia =('a','b')
    oa =('0','1')
    mm = mealymachine.MealyMachine(ia,oa,'machine1')
    e = []
    for i in range(1,4) : # 3 etats
        e.append(mm.add_state(mealymachine.State(f"s{i}")))

    mm.set_initial_state(1)
    mm.add_transition(e[0].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[0].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[2].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[2].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[0].get_id())
    return mm

def build_machine2() -> mealymachine.MealyMachine :
    ia =('a','b')
    oa =('0','1')
    mm = mealymachine.MealyMachine(ia,oa,'machine2')
    e = []
    for i in range(1,4) :
        e.append(mm.add_state(mealymachine.State(f"s{i}")))

    mm.set_initial_state(1)
    mm.add_transition(e[0].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[0].get_id(),mm.input_alphabet[1],mm.output_alphabet[1],e[1].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[2].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[0].get_id())
    return mm



def build_oracle() -> mealymachine.MealyMachine :
    ia =('a','b')
    oa =('0','1','2')
    mm = mealymachine.MealyMachine(ia,oa,'machine1')
    e = []
    for i in range(1,4) :
        e.append(mm.add_state(mealymachine.State(f"s{i}")))

    mm.set_initial_state(0)
    mm.add_transition(e[0].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[0].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[2].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[1].get_id(),mm.input_alphabet[1],mm.output_alphabet[1],e[3].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[2].get_id(),mm.input_alphabet[1],mm.output_alphabet[2],e[3].get_id())
    mm.add_transition(e[3].get_id(),mm.input_alphabet[0],mm.output_alphabet[0],e[1].get_id())
    mm.add_transition(e[3].get_id(),mm.input_alphabet[1],mm.output_alphabet[0],e[3].get_id())
    return mm




def generate_mutationmachinewithoracle() ->(mealymachine.MealyMachine,mealymachine.MealyMachine) :
    mutationmachine, trsoracle = example_mutationmachine()
    oracle = miningbasic.extractSubMachine(trsoracle, mutationmachine, 'oracle')[0]
    return oracle, mutationmachine
