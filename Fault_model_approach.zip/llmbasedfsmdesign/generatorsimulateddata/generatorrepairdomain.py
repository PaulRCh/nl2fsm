from mealymachinemodel import mealymachine
import generatormealymachine

def sizerepairdomain(mutationmachine : mealymachine.MealyMachine) -> int :
    size =1
    for src in mutationmachine.get_states():
        for input in mutationmachine.input_alphabet :
            trs = mutationmachine.get_state(src.get_id()).get_out_transition(input)
            size = size * len(trs)
    return size

def generatemealymachine(ia:list, oa:list, nb_etats=4, uncertaintydegree=2, name="mm") ->(MealyMachine,MealyMachine):
    oracle = generatormealymachine.generateinputcompletemm(ia, oa, nb_etats)
    oracle.set_name("oracle-de-"+ name)
    mutationmachine = generatormealymachine.generatemutationmachine(oracle, uncertaintydegree, name)
    return mutationmachine,oracle


def addoracleinmutationmachine(mutationmachine:mealymachine.MealyMachine, oracle:mealymachine.MealyMachine)->list:
    #assuming that mutation machine and oracle have the same set of state
    #and states have the same id, but not necessarely the transitions
    addedtransitions =[]
    etats = oracle.get_states()
    for src in etats :
        srcmm = mutationmachine.get_state(src.get_id())
        for input in oracle.input_alphabet:
            trsoracle = src.get_out_transition(input)
            trsmm = srcmm.get_out_transition(input)
            trsmm =[] if trsmm==None else trsmm
            print(srcmm.get_id(), input, trsmm)
            if (trsoracle!=None and len(trsoracle)>0):
                for troracle in trsoracle :
                    output = troracle.get_output()
                    for trmm in trsmm :
                        if (trmm.get_output()== output and trmm.get_tgt().get_id()==troracle.get_tgt().get_id()) :
                            break
                    else :
                        tr = mutationmachine.add_transition(troracle.get_src().get_id(),input, output, troracle.get_tgt().get_id())
                        addedtransitions.append(tr.get_id())
    return addedtransitions



def buildrepairdomain(generatedspec:mealymachine.MealyMachine)->mealymachine.MealyMachine:
    repair_domain = generatormealymachine.generateinitialmutationmachine(generatedspec)
    repair_domain.renderInputComplete()
    generatormealymachine.augmentmutationmachinewithinputfault(repair_domain, generatedspec)
    generatormealymachine.augmentmutationmachinewithoutputfault(repair_domain, generatedspec)
    #generatormm.augmentmutationmachinewithtransfertfault(repair_domain,generatedspec)
    return repair_domain
