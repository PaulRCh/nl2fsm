import random
from mealymachinemodel.mealymachine import MealyMachine
from mealymachinemodel.state import State
from utils import affichage
import string

def generatealphabets(nbinputs = 3, nboutputs=2)->(list,list):
  return list(string.ascii_lowercase)[0:nbinputs], [str(i) for i in range(nboutputs)]


def generateinputcompletemm(ia:list, oa:list, nb_etats=4, name="detmachine")->MealyMachine :
    mm = MealyMachine(tuple(ia),tuple(oa))
    mm.set_name(name)
    #ajout des états
    etats=[]
    non_input_complete_states = []
    #print(non_input_complete_states)
    for i in range(1,nb_etats+1):
        non_input_complete_states.append(i)
        etats.append(mm.add_state(State(f's{i}')))
    mm.set_initial_state(1)
    # construire une sous machine accessible
    # seul l'état 0 est accessible au départ
    reachable=[1]
    while (len(reachable)<nb_etats) :
        available_src = [x for x in reachable if x in non_input_complete_states]
        id_src = random.choice(available_src)
        used_input = mm.get_state(id_src).get_defined_input()
        unused_input = [a for a in ia if a not in used_input]
        print(id_src, unused_input)
        input=random.choice(unused_input)
        output=random.choice(oa)
        available_tgt = [x for x in range(1,nb_etats+1) if x not in reachable]
        id_tgt = random.choice(available_tgt) #range(0,nb_etats))
        print(f'{id_src},{input},{output},{id_tgt}')
        mm.add_transition(id_src,input,output,id_tgt)
        # mise à jour
        if (len(unused_input)<=1) :
            non_input_complete_states.remove(id_src)
        if id_src in reachable :
            reachable.append(id_tgt)
    ## ajout des autres transitions
    print("non input complte",non_input_complete_states)
    while (len(non_input_complete_states)>0):
        id_src = random.choice(non_input_complete_states)
        used_input = mm.get_state(id_src).get_defined_input()
        unused_input = [a for a in ia if a not in used_input]
        input=random.choice(unused_input)
        output=random.choice(oa)
        id_tgt = random.choice(range(1,nb_etats+1))
        print(f'{id_src},{input},{output},{id_tgt}')
        mm.add_transition(id_src,input,output,id_tgt)
        # mise à jour
        if (len(unused_input)<=1) :
            non_input_complete_states.remove(id_src)
    ##
    return mm

def generate_trace(mm: MealyMachine, longueur:int) ->list :
    #generate une trace de longeur sous la forme
    # d'une liste de 'i/o'
    rst = list()
    etat_courant = mm.get_state(mm.get_initial_state_id())
    while (len(rst)<longueur) :
        input =  random.choice(etat_courant.get_defined_input())
        transitions = etat_courant.get_out_transition(input)
        transition = random.choice(transitions)
        rst.append(f'{transition.get_input()}/{transition.get_output()}')
        etat_courant = transition.get_tgt()
    return rst


def generatemutationmachine(oracle:MealyMachine, uncertaintydegree=3, name="") -> MealyMachine :
    mutationmachine = oracle.dupliquer(name)
    nom = name if name!="" else "mutation-"+oracle.get_name()
    mutationmachine.set_name(nom)
    #
    ia = oracle.input_alphabet
    oa = oracle.output_alphabet
    etats = mutationmachine.get_states()
    for src in etats :
        for input in ia :
            for i in range(uncertaintydegree-1):
                output= random.choice(oa)
                tgt= random.choice(list(etats))
                mutationmachine.add_transition(src.get_id(),input,output,tgt.get_id())
    return mutationmachine


def generateinitialmutationmachine(oracle:MealyMachine, name=None) -> MealyMachine :
    mutationmachine = oracle.dupliquer(name)
    nom = name if name!=None else "mutation-"+oracle.get_name()
    mutationmachine.set_name(nom)
    return mutationmachine

def augmentmutationmachinewithinputfault(mutationmachine:MealyMachine, originalDfsm:MealyMachine, name=None) -> MealyMachine :
    # when there is no input on a transition
    nom = name if name!=None else mutationmachine.get_name()
    mutationmachine.set_name(nom)
    #
    etats = originalDfsm.get_states()
    for src in etats :
        for input in originalDfsm.input_alphabet :
            trs = src.get_out_transition(input)
            if (trs==None) :
                for output in originalDfsm.output_alphabet :
                    for tgt in etats :
                        mutationmachine.add_transition(src.get_id(), input,output,tgt.get_id())

    return mutationmachine


def augmentmutationmachinewithoutputfault(mutationmachine:MealyMachine,originalDfsm:MealyMachine,  name=None) -> MealyMachine :
    # when there is no input on a transition
    nom = name if name!=None else mutationmachine.get_name()
    mutationmachine.set_name(nom)
    #
    etats = originalDfsm.get_states()
    for src in etats :
        for input in originalDfsm.input_alphabet :
            trs = src.get_out_transition(input)
            if (trs!=None and len(trs)==1) :
                existing_tr = trs[0]
                tgt = existing_tr.get_tgt()
                output = existing_tr.get_output()
                for newoutput in originalDfsm.output_alphabet :
                    if (newoutput!=output):
                        mutationmachine.add_transition(src.get_id(), input,newoutput,tgt.get_id())

    return mutationmachine


def augmentmutationmachinewithtransfertfault(mutationmachine:MealyMachine, originalDfsm:MealyMachine,name=None) -> MealyMachine :
    # when there is no input on a transition
    nom = name if name!=None else mutationmachine.get_name()
    mutationmachine.set_name(nom)
    #
    etats = originalDfsm.get_states()
    for src in etats :
        for input in originalDfsm.input_alphabet :
            trs = src.get_out_transition(input)
            if (trs!=None and len(trs)==1) :
                existing_tr = trs[0]
                tgt = existing_tr.get_tgt()
                output = existing_tr.get_output()
                for newtgt in etats  :
                    if (newtgt.get_id()!=tgt.get_id()):
                        mutationmachine.add_transition(src.get_id(), input,output,newtgt.get_id())

    return mutationmachine


if __name__ == "__main__":
    ia =['a','b']
    oa =['0','1']
    oracle = generateinputcompletemm(ia, oa)
    affichage.show_mealy_machine(oracle)
    print(generate_trace(oracle,5))
    mm = generatemutationmachine(oracle,2,"mm")
    affichage.show_mealy_machine(mm)

