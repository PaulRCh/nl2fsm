#https://graphviz.readthedocs.io/en/stable/manual.html
from mealymachinemodel.state import State
from mealymachinemodel.transition import Transition
import io
import copy
import random
from collections import deque


class MealyMachine(object) :
    input_alphabet : tuple
    output_alphabet : tuple
    _name : str
    _states : dict
    _id_initial_state : int #superieur ou égal à 1, les identifiant d'état sont supéieurà 1
    _transitions: dict #[id:tr,]
    def __init__(self, ia:tuple, oa:tuple, name="mealymachinemodel"):
        self._states={}
        self._transitions={}
        self.input_alphabet = ia
        self.output_alphabet = oa
        self._id_initial_state = -1
        self._name =name

    def set_name(self,name:str):
        self._name = name

    def get_name(self)->str:
        return self._name

    def __str__(self)->str:
        buffer = io.StringIO()
        for tr in self._transitions.values() :
            buffer.write(f'{tr}\n')
        return buffer.getvalue()

    def _get_next_state_id(self):
        return len(self._states.keys())+1

    def _get_next_transition_id(self):
        return len(self._transitions.keys())+1

    def set_initial_state(self, id:int):
        self._id_initial_state = id

    def get_initial_state_id(self) ->int :
        return self._id_initial_state

    def get_initial_state(self)->State:
        return self.get_state(self.get_initial_state_id())

    def get_state(self, id)->State:
        if id in self._states.keys():
            return self._states[id]
        return None

    def get_states(self) ->list :
        return self._states.values()

    def add_state(self, etat:State)->State:
        id = etat.get_id()
        if id ==-1 :
            id = self._get_next_state_id()
            etat.set_id(id)
            self._states[id] = etat
        else :
            self._states[id] = etat
        return etat

    def get_transition(self, id:int)->Transition:
        return self._transitions[id]

    def get_transitions(self)->list:
        return self._transitions.values()

    def add_transition(self, idSrc: int, input: str, output:str, idTgt:int, id=-1):
        src = self.get_state(idSrc)
        tgt = self.get_state(idTgt)
        #Todo : tester si src et tgt ne sont pas null
        tr = Transition(src,input,output,tgt)
        if id ==-1 :
            id = self._get_next_transition_id()
        tr.set_id(id)
        self._transitions[id] = tr
        return tr

    def add_knowntransition(self, tr:Transition):
        idsrc = tr.get_src().get_id()
        idtgt = tr.get_tgt().get_id()
        if idsrc not in self._states :
            self.add_state(State(tr.get_src().get_name(),idsrc))
        if idtgt not in self._states :
            self.add_state(State(tr.get_tgt().get_name(),idtgt))
        return self.add_transition(idsrc,tr.get_input(),tr.get_output(),idtgt,tr.get_id())

    def computeanouputsequence(self, iseq:list, rand=False) -> tuple:
        rst = [] #list of outputs
        path = [] # list of transitions
        etatcourant = self.get_initial_state()
        for input in iseq :
            transitions = etatcourant.get_out_transition(input)
            if len(transitions) > 0 :
                if rand :
                    transition = transitions[random.choice(list(range(len(transitions))))]
                else:
                    transition = transitions[0]
                output = transition.get_output()
                rst.append(output)
                path.append(transition.get_id())
                etatcourant = transition.get_tgt()
            else :
                break # il faut lever une exception
        else :
            return rst, path
        return [],[]

    #def computealloutputsequences(self, iseq:list) ->list:
        #configurations_courante = deque()

    def find_a_path_to_one_state_in(self, target_state_ids:set):
        etat_a_visiter = [([],[],self.get_initial_state())]
        etat_deja_visite = set()
        while len(etat_a_visiter) > 0 :
            iseq, path, etat_courant = etat_a_visiter.pop(0)
            etat_deja_visite.add(etat_courant.get_id())
            transitions = etat_courant.get_out_transition()
            for trs in transitions :
                for tr in trs :
                    input = tr.get_input()
                    tgt = tr.get_tgt()
                    if tgt.get_id() not in etat_deja_visite :
                        iseq_new = list(iseq)
                        iseq_new.append(input)
                        path_new = list(path)
                        path_new.append(tr)
                        etat_a_visiter.append((iseq_new,path_new,tgt))
                        if tgt.get_id() in target_state_ids :
                            return iseq_new,path_new
        return [],[]



    def dupliquer (self, newname=None)  :
        rst =copy.deepcopy(self)
        if newname==None :
            rst.set_name(self._name+"copy")
        else :
            rst.set_name(newname)
        return rst


    def toDot(self) -> str :
        rst =""
        rst+= f'digraph {self._name}' + "{"
        for cle in self._states.keys() :
            rst += "\n\t" + self._states[cle].toDot()

        for cle in self._transitions.keys() :
            rst += "\n\t" + self._transitions[cle].toDot()
        rst+="\n}"
        return rst

    def toNL(self) -> str :
      rst =""
      for cle in self._transitions.keys() :
         rst +=  " "+self._transitions[cle].toNL() + ". "
      return rst

    def isComplete(self) ->dict :
        rst= dict ()
        for src_id in self._states.keys() :
            s = self.get_state(src_id)
            for input in self.input_alphabet :
                if s.get_out_transition(input)==None:
                    rst[s.get_id()] = input
        return rst

    def buildComplete(self) :
        rst=MealyMachine(self.input_alphabet,self.output_alphabet,self.get_name()+"inputcomplete")
        for s in self._states.values():
            rst.add_state(State(s.get_name(), s.get_id()))
        for t in self._transitions.values() :
            rst.add_transition(t.get_src().get_id(),t.get_input(), t.get_output(),t.get_tgt().get_id(),t.get_id())
        rst.set_initial_state(self._id_initial_state)
        rst.renderInputComplete()
        return rst

    def renderInputComplete(self):
        for s in self.get_states():
            for input in self.input_alphabet :
                if s.get_out_transition(input)==None:
                    self.add_transition(s.get_id(), input, self.output_alphabet[0], s.get_id())







