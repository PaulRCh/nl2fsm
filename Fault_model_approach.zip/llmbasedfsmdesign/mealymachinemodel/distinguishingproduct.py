from collections import deque

from mealymachinemodel.state import State
from mealymachinemodel.mealymachine import MealyMachine
from mealymachinemodel.transition import Transition

class ProductState(State):
    state1 : State
    state2 : State
    pair_id : str
    diff : bool

    def __init__(self, e1:State, e2:State, diff=False):
        super().__init__(f'{e1.get_id()}.{e2.get_id()}')
        self.state1 = e1
        self.state2 = e2
        self.pair_id=-1
        self.diff=diff
        d = 1 if self.diff else 0
        self.set_name(self.get_name()+'.'+ str(d))

    def get_pair_id(self)->str:
        return self.pair_id

    def set_pair_id(self, p_id:str):
        self.pair_id =p_id


class ProductMealyMachine(MealyMachine) :
    diff_states_id : set
    machine1 : MealyMachine
    machine2 : MealyMachine
    pairedid_to_id : dict #[pair_id:id]

    def __init__(self, mm1: MealyMachine, mm2: MealyMachine, name=None):
        super().__init__(mm1.input_alphabet,mm1.output_alphabet,name)
        name = "produit-"+mm1.get_name()+"-"+mm2.get_name() if name==None else name
        self.set_name(name)
        self.machine1=mm1
        self.machine2=mm2
        self.pairedid_to_id =dict()
        self.diff_states_id = set()

    @staticmethod
    def build_pair_id(e1:State, e2:State, diff=False)->str:
        d = 1 if diff else 0
        return str(e1.get_id())+'.'+str(e2.get_id())+'.'+str(d)

    def _determine_and_add_next_state(self,  tr1:Transition, tr2: Transition) -> Transition:
        tgt1, tgt2 = tr1.get_tgt(), tr2.get_tgt()
        output1, output2 = tr1.get_output(), tr2.get_output()
        # retrouver l'état cible dans le produit ou le crée s'il
        # n'existe pas encore
        output = output1 if (output1 ==output2)  else f'{output1}.{output2}'
        diff =  False if (output1 ==output2)  else  True
        pairid_tgt = ProductMealyMachine.build_pair_id(tgt1,tgt2,diff)
        if pairid_tgt in self.pairedid_to_id:
            id_tgt = self.pairedid_to_id[pairid_tgt]
            tgt = self.get_state(id_tgt)
        else :
            tgt = self.add_state(ProductState(tgt1,tgt2,diff))
            tgt.set_pair_id(pairid_tgt)
            self.pairedid_to_id[pairid_tgt] = tgt.get_id()


        return tgt, output, diff



    def make_product(self):
        #initialisation
        src = ProductState(self.machine1.get_initial_state(),
                                   self.machine2.get_initial_state())
        src = self.add_state(src)
        self.set_initial_state(src.get_id())
        pairid_src = ProductMealyMachine.build_pair_id(src.state1, src.state2)
        src.set_pair_id(pairid_src)
        self.pairedid_to_id[pairid_src] = src.get_id()
        #
        aVisiter = deque()
        dejaVisite = list() #
        aVisiter.append(src)
        while len(aVisiter) > 0 :
            src = aVisiter.popleft()
            dejaVisite.append(src)
            src1, src2 = src.state1, src.state2
            for a in self.input_alphabet :
                trs1, trs2 = src1.get_out_transition(a), src2.get_out_transition(a)
                for tr1 in trs1:
                    for tr2 in trs2 :
                        tgt, output, diff = self._determine_and_add_next_state(tr1,tr2)
                        #ajout de la transition
                        tr = self.add_transition(src.get_id(), a, output, tgt.get_id())
                        if diff==True :
                            self.diff_states_id.add(tr.get_tgt().get_id())
                        if (tr.get_tgt() not in dejaVisite) \
                                and (tr.get_tgt() not in aVisiter) :
                            aVisiter.append(tr.get_tgt())
        return self

    def make_simple_product(self):
        #initialisation
        src = ProductState(self.machine1.get_initial_state(),
                                   self.machine2.get_initial_state())
        src = self.add_state(src)
        self.set_initial_state(src.get_id())
        pairid_src = ProductMealyMachine.build_pair_id(src.state1, src.state2)
        src.set_pair_id(pairid_src)
        self.pairedid_to_id[pairid_src] = src.get_id()
        #
        aVisiter = deque()
        dejaVisite = list() #
        aVisiter.append(src)
        while len(aVisiter) > 0 :
            src = aVisiter.popleft()
            dejaVisite.append(src)
            src1, src2 = src.state1, src.state2
            for a in self.input_alphabet :
                trs1, trs2 = src1.get_out_transition(a), src2.get_out_transition(a)
                for tr1 in trs1:
                    for tr2 in trs2 :
                        tgt, output, diff = self._determine_and_add_next_state(tr1,tr2)
                        #ajout de la transition
                        tr = self.add_transition(src.get_id(), a, output, tgt.get_id())
                        if diff==True :
                            self.diff_states_id.add(tr.get_tgt().get_id())
                        if (diff!=True and tr.get_tgt() not in dejaVisite) \
                                and (tr.get_tgt() not in aVisiter) :
                            aVisiter.append(tr.get_tgt())
        return self

    def find_a_path_to_diff_state(self) :
        return self.find_a_path_to_one_state_in(self.diff_states_id)




