import copy
import random

from mealymachinemodel import distinguishingproduct
from mealymachinemodel import mealymachine
from mealymachinemodel import state
from utils import mysolver, affichage
from collections import deque

nbproduit = 0
nbsubmachine=0

def addcompatibletransition(statetransitionchoice:map,tr:mealymachine.Transition)->map :
    #statetransitionchoice est un map de la forme {stateid:{input:transitionId},...},
    srcStateId = tr.get_src().get_id()
    input = tr.get_input()
    result=True
    if srcStateId in statetransitionchoice :
        if input not in statetransitionchoice[srcStateId] :
            statetransitionchoice[srcStateId][input] = tr.get_id()
    else:
        statetransitionchoice[srcStateId]={input:tr.get_id()}
    return statetransitionchoice

def compatible(statetransitionchoice:map,tr:mealymachine.Transition)->bool:
    #statetransitionchoice est un map de la forme {stateid:{input:transitionId},...},
    srcStateId = tr.get_src().get_id()
    input = tr.get_input()
    result=True
    if srcStateId in statetransitionchoice :
        if input in statetransitionchoice[srcStateId] :
            selectedTransitionId= statetransitionchoice[srcStateId][input]
            result = selectedTransitionId == tr.get_id()
    return result

def encode_forbid_badexecutions(mmencoding: mysolver.SolverSat, badexecutions:list, mutationmachine:mealymachine.MealyMachine) :
    for path_producedoutput in badexecutions :
         clause =[]
         for tr_id in path_producedoutput[0] :
            tr = mutationmachine.get_transition(tr_id)
            if (len(tr.get_src().get_out_transition(tr.get_input())) >1) and -tr_id not in clause :
                clause.append(-tr_id)
         mmencoding.addclause(clause)
    return mmencoding



def partitionexecutions(deterministic_executions:list, expected_output:list)->(list,list) :
    goodexecutions, badexecutions = [],[]
    for path_outputseq in deterministic_executions :
        producedoutput=path_outputseq[1]
        if producedoutput==expected_output :
            goodexecutions.append(path_outputseq)
        else :
            badexecutions.append(path_outputseq)
    #
    return goodexecutions,badexecutions

def computeoutputsequence(oracle: mealymachine.MealyMachine,distinputseq:list) :
    return oracle.computeanouputsequence(distinputseq)[0]

def deterministicexecutions(mm: mealymachine.MealyMachine, distinputseq:list) ->list :
    # return list of pair (deterministicpath, ouputsequence)
    dpath_outputlist=[]
    # an element in the list is a quatruple configuration [path,outputseq, {stateid:{input:transition},...}, state]
    s =mm.get_initial_state()
    currentConf =[[],[],{},s]
    currentConfs=deque()
    currentConfs.append(currentConf)
    nextConfs=deque()
    for input in distinputseq :
        while len(currentConfs)>=1 :
            currentConf = currentConfs.pop()
            curentpath:list = currentConf[0]
            currentoutput:list = currentConf[1]
            currstatetransitionchoice:map=currentConf[2]
            currentstate :state.State = currentConf[3]
            for tr in currentstate.get_out_transition(input):
                if compatible(currstatetransitionchoice,tr) :
                    nextpath:list = copy.deepcopy(curentpath)
                    nextpath.append(tr.get_id())
                    nextoutput:list= copy.deepcopy(currentoutput)
                    nextoutput.append(tr.get_output())
                    nextstatetransitionchoice= copy.deepcopy(currentConf[2])
                    addcompatibletransition(nextstatetransitionchoice,tr)
                    nextstate = tr.get_tgt()
                    nextConf=[nextpath, nextoutput, nextstatetransitionchoice, nextstate]
                    nextConfs.append(nextConf)
        currentConfs=nextConfs
        nextConfs=deque()
    return currentConfs

def addClauseForbidMachine(mmencoding: mysolver.SolverSat, candidate2:mealymachine.MealyMachine, mutationmachine:mealymachine.MealyMachine):
    clause =[]
    for tr in candidate2.get_transitions() :
        src_id = tr.get_src().get_id()
        srcinmutationmachine = mutationmachine.get_state(src_id)
        if len(srcinmutationmachine.get_out_transition(tr.get_input())) >1 :
            clause.append(-tr.get_id())
    mmencoding.addclause(clause)


def checkequivalence(mm1:mealymachine.MealyMachine,mm2:mealymachine.MealyMachine)->(bool, list) :
    global nbproduit
    produit = distinguishingproduct.ProductMealyMachine(mm1, mm2, f'product{nbproduit}' + mm1.get_name() + mm2.get_name())
    nbproduit = nbproduit+1
    produit.make_product()
    iseq, path = produit.find_a_path_to_diff_state()
    return (len(iseq)==0, iseq)


def extractSubMachine(transitionIdList:list, mutationmachine:mealymachine.MealyMachine, name="submachine") -> (mealymachine.MealyMachine, list,list):
    submachine= mealymachine.MealyMachine(mutationmachine.input_alphabet,mutationmachine.output_alphabet,name)
    submachine.set_initial_state(mutationmachine.get_initial_state().get_id())
    toVisitStateId = deque()
    visitedState = set()
    toVisitStateId.append(mutationmachine.get_initial_state().get_id())
    usedUncertainTransitionIds = []
    usedCertainTransitionIds =[]
    while (len(toVisitStateId)>0):
        idsrc = toVisitStateId.pop()
        visitedState.add(idsrc)
        for input in mutationmachine.input_alphabet :
            trlist = mutationmachine.get_state(idsrc).get_out_transition(input)
            trlist =[] if trlist==None else trlist
            if (len(trlist)==1) :
                traajouter = trlist[0]
                if traajouter.get_id() not in usedCertainTransitionIds :
                    usedCertainTransitionIds.append(traajouter.get_id())
            elif (len(trlist)>1) :
                for tr in trlist :
                    if tr.get_id() in transitionIdList :
                        traajouter= tr
                        if traajouter.get_id() not in usedUncertainTransitionIds:
                            usedUncertainTransitionIds.append(traajouter.get_id())
                        break
            traajouter = submachine.add_knowntransition(traajouter)
            if traajouter.get_tgt().get_id() not in visitedState:
                toVisitStateId.append(traajouter.get_tgt().get_id())
    global extractedmachines
    extractedmachines.append([f't{tr.get_id()}' for tr in submachine.get_transitions()])
    return submachine,usedUncertainTransitionIds,usedCertainTransitionIds


candidate1 = None
candidate2 = None
usedUncertainTransitionIds1 = None
usedUncertainTransitionIds2 = None
usedCertainTransitionIds1 = None
usedCertainTransitionIds2 = None
extractedmachines=list()



def searchadistinguishingsequence(mmencoding: mysolver.SolverSat, mutationmachine:mealymachine.MealyMachine) -> (list, mealymachine.MealyMachine, mealymachine.MealyMachine,) :
    distinputseq =[]
    global candidate1
    global candidate2
    global usedUncertainTransitionIds1
    global usedUncertainTransitionIds2
    global usedCertainTransitionIds1
    global usedCertainTransitionIds2
    if candidate1 == None:
        found1, transitionIdList = mmencoding.generatePositiveLiteralinSatModel()
        if found1 :
            global nbsubmachine
            nbsubmachine = nbsubmachine+1
            newcandidate,usedUncertainTransitionIds, usedCertainTransitionIds = extractSubMachine(transitionIdList, mutationmachine, "submachine"+str(nbsubmachine))
            candidate1 = newcandidate
            usedUncertainTransitionIds1 = usedUncertainTransitionIds
            usedCertainTransitionIds1 = usedCertainTransitionIds
    if candidate1!=None :
        candidate2=candidate1
        usedUncertainTransitionIds2 = usedUncertainTransitionIds1
        usedCertainTransitionIds2 = usedCertainTransitionIds1
        equivcandidate1and2 = True
        distinputseq=[]
        sous_espace_recherche = copy.deepcopy(usedUncertainTransitionIds2)
        while(equivcandidate1and2 and len(sous_espace_recherche)>0) :
            trId_choisi = random.choice(sous_espace_recherche)
            assumption=[-trId_choisi]
            found2, transitionIdList = mmencoding.generatePositiveLiteralinSatModel(assumption)
            if  found2:
                nbsubmachine = nbsubmachine+1
                candidate2,usedUncertainTransitionIds2, usedCertainTransitionIds2 = extractSubMachine(transitionIdList, mutationmachine, "submachine"+str(nbsubmachine))
                equivcandidate1and2, distinputseq = checkequivalence(candidate1,candidate2)
                if equivcandidate1and2 :
                    addClauseForbidMachine(mmencoding,candidate2,mutationmachine)
            else:
                sous_espace_recherche.remove(trId_choisi)
    return distinputseq, candidate1, candidate2

def encode_sat(mutationmachine : mealymachine.MealyMachine) -> mysolver.SolverSat :
     mmencoding = mysolver.SolverSat()
     for state in mutationmachine.get_states() :
         for input in state.get_defined_input() :
             aumoinsunetransition_clause = []
             outtransitions_with_input = state.get_out_transition(input)
             if (len (outtransitions_with_input) > 1) :
                for transition in  outtransitions_with_input:
                    aumoinsunetransition_clause.append(transition.get_id())
                    for transition2 in outtransitions_with_input :
                        if transition2.get_id() != transition.get_id():
                            mmencoding.addclause([-transition.get_id(), -transition2.get_id()])
                mmencoding.addclause(aumoinsunetransition_clause)
     return mmencoding

def updateCandidate(distinputseq:list,expected_output:list,mmencoding: mysolver.SolverSat,mutationmachine:mealymachine.MealyMachine) :
    global candidate1
    global candidate2
    global usedUncertainTransitionIds1
    global usedUncertainTransitionIds2
    global usedCertainTransitionIds1
    global usedCertainTransitionIds2
    produced_output1 = computeoutputsequence(candidate1,distinputseq)
    produced_output2 = computeoutputsequence(candidate2,distinputseq)
    if produced_output2!=expected_output:
        candidate2 = None
        usedUncertainTransitionIds2 = None
        usedCertainTransitionIds2 = None
    if produced_output1!=expected_output:
        candidate1 = candidate2
        usedUncertainTransitionIds1 = usedUncertainTransitionIds2
        usedCertainTransitionIds1= usedCertainTransitionIds2




def mining(mutationmachine: mealymachine.MealyMachine, oracle : mealymachine.MealyMachine) -> (mealymachine.MealyMachine,list) :
    global candidate1
    global candidate2
    testsuite=[]
    mmencoding = encode_sat(mutationmachine)
    #
    distinputseq,  candidate1, candidate2,  = searchadistinguishingsequence(mmencoding, mutationmachine)
    nb=100
    while len(distinputseq)>=1 and nb>0:
        testsuite.append(distinputseq)
        deterministic_executions = deterministicexecutions(mutationmachine, distinputseq)
        expected_output = computeoutputsequence(oracle,distinputseq)
        updateCandidate(distinputseq, expected_output,mmencoding,mutationmachine)
        goodexecutions, badexecutions = partitionexecutions(deterministic_executions, expected_output)
        mmencoding = encode_forbid_badexecutions(mmencoding,badexecutions, mutationmachine)
        distinputseq,  candidate1, candidate2,  = searchadistinguishingsequence(mmencoding, mutationmachine)
        nb=nb-1
        print(nb)
    return candidate1, testsuite



