from pysat.solvers import Solver
class SolverSat :
    def __init__(self):
        self._solveur = Solver("g3",incr=True) #Minicard

    def addclause(self, clause:list):
        self._solveur.add_clause(clause)

    def generatePositiveLiteralinSatModel(self, assumptions=[]) ->(bool, list):
        #assumptions permet de faire la resolution avec une hypothèse temporaire
        #print("resolution de la contrainte")
        literalList =[]
        if (self._solveur.solve(assumptions)==True) :
            model = self._solveur.get_model()
            for id_litteral in model :
                if (id_litteral > 0) :
                    literalList.append(id_litteral)
            return True, literalList
        else :
            #print("mysolveur.py : Il n'a plus de sousmachine")
            return False, None

