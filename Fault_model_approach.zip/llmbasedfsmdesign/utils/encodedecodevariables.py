#code un tuple d'entier en un entier
"""
def tuple_to_int(tup, max_vals):
    assert len(tup) == len(max_vals), "Tuple and max_vals must have the same length."
    n = 0
    factor = 1
    for i in range(len(tup)):
        n += tup[i] * factor
        factor *= (max_vals[i] + 1)
    return n+1


#decode un entier en un tuple d'entier
def int_to_tuple(n, max_vals):
    tup = []
    n=n-1
    for max_val in max_vals:
        tup.append(n % (max_val + 1))
        n //= (max_val + 1)
    return tuple(tup)
"""
