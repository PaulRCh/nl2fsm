from mealymachinemodel import mealymachine,distinguishingproduct
from generatorsimulateddata import generatormealymachine, generatordescription
from llmprompting import gptprompt
from miningdfsmfromrepairdomain import miningbasic

global_stats =  {"are_different":0, "same_number_state":0, "missing_tr":0, "unwanted_tr":0,"nb_transfert_output_fault":0, "nb_input_fault":0, "nb_output_fault":0, "nb_transfert_fault":0, "non_det_state":0}
max_stats = {"are_different":0, "same_number_state":0, "missing_tr":0, "unwanted_tr":0,"nb_transfert_output_fault":0, "nb_input_fault":0, "nb_output_fault":0, "nb_transfert_fault":0, "non_det_state":0}

def updatestats(difftransitions) :
    global_stats["are_different"]+=difftransitions["are_different"]
    global_stats["same_number_state"]+=difftransitions["same_number_state"]
    global_stats["missing_tr"]+=len(difftransitions["missing_tr"])
    global_stats["unwanted_tr"]+=len(difftransitions["unwanted_tr"])
    global_stats["nb_transfert_output_fault"]+=difftransitions["nb_transfert_output_fault"]
    global_stats["nb_input_fault"]+=difftransitions["nb_input_fault"]
    global_stats["nb_output_fault"]+=difftransitions["nb_output_fault"]
    global_stats["nb_transfert_fault"]+=difftransitions["nb_transfert_fault"]
    global_stats["non_det_state"]+=len(difftransitions["non_det_state"].keys())
    #
    max_stats["are_different"]= max(max_stats["are_different"], difftransitions["are_different"])
    max_stats["same_number_state"] = max(max_stats["same_number_state"],difftransitions["same_number_state"])
    max_stats["missing_tr"]= max(max_stats["missing_tr"], len(difftransitions["missing_tr"]))
    max_stats["unwanted_tr"]=max (max_stats["unwanted_tr"], len(difftransitions["unwanted_tr"]))
    max_stats["nb_transfert_output_fault"]=max(max_stats["nb_transfert_output_fault"],difftransitions["nb_transfert_output_fault"])
    max_stats["nb_input_fault"]= max(max_stats["nb_input_fault"],difftransitions["nb_input_fault"])
    max_stats["nb_output_fault"]= max(max_stats["nb_output_fault"],difftransitions["nb_output_fault"])
    max_stats["nb_transfert_fault"]= max(max_stats["nb_transfert_fault"], difftransitions["nb_transfert_fault"])
    max_stats["non_det_state"] = max(max_stats["non_det_state"],len(difftransitions["non_det_state"].keys()))


def savestats(nbetats, id_oracle, Dossier):
    fichier = open(Dossier+"evolution_global_stat_"+str(nbetats)+".txt","a+")
    fichier.write(f'{id_oracle} :=> {global_stats}\n')
    fichier.close()
    fichier = open(Dossier+"evolution_max_stat_"+str(nbetats)+".txt","a+")
    fichier.write(f'{id_oracle} :=> {max_stats}\n')
    fichier.close()
    return None


def generatealphabets(nbinp=5, nbout=2) ->(list, list) :
    return generatormealymachine.generatealphabets(nbinputs=nbinp, nboutputs=nbinp)

def generateoracle(ia, oa, nbetats=2, nom="oracle") -> mealymachine.MealyMachine :
    return generatormealymachine.generateinputcompletemm(ia, oa, nb_etats=nbetats, name=nom)


def saveoracle(oracle:mealymachine.MealyMachine,  DossierOracle):
    fichier = open(DossierOracle+oracle.get_name()+".dot", "w")
    fichier.write(oracle.toDot())
    fichier.close()
    return None

def descriptionfororacle(oracle)-> str :
    return generatordescription.generatedescription(oracle)


def savedescription(description, oracle:mealymachine.MealyMachine, DossierDescription):
    fichier = open(DossierDescription+"description_"+oracle.get_name()+".txt","w")
    fichier.write(description)
    fichier.close()
    return None


def queryllm(description):
    return gptprompt.generate_response(description)


def saveoutputllm(outputllm, oracle:mealymachine.MealyMachine, DossierOutputllm):
    fichier = open(DossierOutputllm+"outputllm4_"+oracle.get_name()+".txt","w")
    fichier.write(outputllm)
    fichier.close()
    return None


def parseoutputllm(outputllm, oracle:mealymachine.MealyMachine, DossierOutputllm=None)->mealymachine.MealyMachine:
    if (DossierOutputllm!=None):
        fichier = open(DossierOutputllm+"outputllm4_"+oracle.get_name()+".txt","r")
        ligne = fichier.read()
        fichier.close()
    else:
        ligne = outputllm
    lignes = ligne.split(sep="\n")
    producedFsm = mealymachine.MealyMachine(oracle.input_alphabet,oracle.output_alphabet,"generated4_"+oracle.get_name())
    for transition in lignes[1:len(lignes)-1]:
        elements = transition.split(sep=" ")
        idsrc = int(elements[0][1:])
        if producedFsm.get_state(idsrc) ==None :
            producedFsm.add_state(mealymachine.State(f"s{idsrc}",idsrc))
        idtgt = int(elements[2][1:])
        if producedFsm.get_state(idtgt) ==None :
            producedFsm.add_state(mealymachine.State(f"s{idtgt}",idtgt))
        input= elements[1][0]
        output = elements[1][2]
        tr = producedFsm.add_transition(idsrc,input,output,idtgt)

    producedFsm.set_initial_state(1)

    return producedFsm


def savegeneratedspec(generatedSpec:mealymachine.MealyMachine, DossierGeneratedSpec):
    saveoracle(generatedSpec,DossierGeneratedSpec)


def syntacticequivalence(oracle:mealymachine.MealyMachine, generatedspec:mealymachine.MealyMachine):
    rst ={"are_different":0, "same_number_state":0, "missing_tr":[], "unwanted_tr":[],"nb_transfert_output_fault":0, "nb_input_fault":0, "nb_output_fault":0, "nb_transfert_fault":0, "non_det_state":{}}
    if len(oracle.get_states())==len(generatedspec.get_states()):
        rst["same_number_state"] = 0
    else :
        rst["same_number_state"] = 1
        rst["are_different"]= 1
    for s in oracle.get_states():
        idsrc = s.get_id()
        for input in oracle.input_alphabet :
            trs = s.get_out_transition(input)
            if trs!=None and len(trs)>0 :
                tr = trs[0]
                idtgt,  output =  tr.get_tgt().get_id(),  tr.get_output()
                idsrc2 =idsrc
                trs2 = generatedspec.get_state(idsrc2).get_out_transition(input)
                if trs2!=None  :
                    if len(trs2)>1:
                        if idsrc2 not in rst["non_det_state"] : rst["non_det_state"][idsrc2] = []
                        rst["non_det_state"][idsrc2].append(input)
                        rst["are_different"]=1
                    elif len(trs2)==1 :
                        tr2 = trs2[0]
                        idtgt2,  output2 =  tr2.get_tgt().get_id(),  tr2.get_output()
                        if (output2!=output) and (idtgt2!=idtgt):
                            rst["nb_transfert_output_fault"]+=1
                        if (output2!=output):
                            rst["nb_output_fault"]+=1
                            rst["unwanted_tr"].append(tr2)
                            rst["missing_tr"].append(tr)
                            rst["are_different"]=1
                        if (idtgt2!=idtgt):
                            rst["nb_transfert_fault"]+=1
                            rst["unwanted_tr"].append(tr2)
                            rst["missing_tr"].append(tr)
                            rst["are_different"]=1
                    else :
                        rst["nb_input_fault"]+=1
                        rst["missing_tr"].append(tr)
                        rst["are_different"]=1
                else :
                    rst["nb_input_fault"]+=1
                    rst["missing_tr"].append(tr)
                    rst["are_different"]=1


    return rst

def afficheDifference(rst) :
    print(rst["are_different"], end=":")
    print(rst["same_number_state"], end=":")
    missing_tr = rst["missing_tr"]
    for tr in missing_tr :
        print(tr, end=",")
    print(":")
    unwanted_tr = rst["unwanted_tr"]
    for tr in unwanted_tr :
        print(tr, end=",")
    print(":")

    print(f'{rst["nb_input_fault"]} : {rst["nb_output_fault"]}: {rst["nb_transfert_fault"]}', end=":")
    print(f'{rst["nb_transfert_output_fault"]}: {rst["non_det_state"]}')




def behaviorequivalence(oracle, generatedspec)->(list, distinguishingproduct.ProductMealyMachine):
    produit = distinguishingproduct.ProductMealyMachine(oracle, generatedspec)
    produit.make_simple_product() #produit.make_product()
    iseq, path = produit.find_a_path_to_diff_state()
    return iseq, produit


def saveproduct(product, DossierProduct):
    fichier = open(DossierProduct+product.get_name()+".dot", "w")
    fichier.write(product.toDot())
    fichier.close()
    return None


def savedifftransitions(rst, oracle, generatedfsm,DossierDiffTransitions):
    fichier = open(DossierDiffTransitions+oracle.get_name()+"-"+ generatedfsm.get_name() +".txt", "w")
    fichier.write(str(rst["are_different"])+"\n")
    fichier.write(str(rst["same_number_state"])+"\n")
    missing_tr = rst["missing_tr"]
    fichier.write("Missing transitions: \n")
    for tr in missing_tr :
        fichier.write(str(tr) + "\n")
    fichier.write("Unwanted transitions:")
    unwanted_tr = rst["unwanted_tr"]
    for tr in unwanted_tr :
        fichier.write(str(tr) +"\n")
    fichier.write("\n")
    fichier.write(f'nb input fault = {rst["nb_input_fault"]} \n')
    fichier.write(f'nb output fault = {rst["nb_output_fault"]} \n')
    fichier.write(f'nb transfert fault = {rst["nb_transfert_fault"]} \n')
    fichier.write(f'nb transfert output fault = {rst["nb_transfert_output_fault"]} \n')
    fichier.write(f'non determinism = {rst["non_det_state"]} \n')
    fichier.close()










