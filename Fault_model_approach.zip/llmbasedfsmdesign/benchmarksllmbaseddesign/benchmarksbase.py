from openai import OpenAI
from benchmarksllmbaseddesign import methods
from llmprompting import gptsession, makeprompts





DossierOracle ="./evaluationlogdata/oracles/"
DossierGeneratedSpec = DossierOracle
DossierProduct = DossierOracle
DossierDescription = "./evaluationlogdata/descriptions/"
DossierOutputllm = "./evaluationlogdata/outputllm/"
DossierDiffTransitions = DossierOutputllm
DossierStats = "./evaluationlogdata/stats/"

if __name__=="__main__":
    #
    nbfaultygeneratedSpec = dict()
    nbrepairdomain_augmentedwithoracle = dict()
    nbmax_added_transition = dict()
    nbrepaired_generatedFsm = dict()
    nbmax_nboutputsequencequery = dict()
    maxlengthoutputsequencequery = dict()
    #
    faults=dict()
    ia, oa = methods.generatealphabets(nbinp=5, nbout=2)
    #generer l'oracle
    for nbetats in [5] :
        nbfaultygeneratedSpec[nbetats] = 0
        nbrepairdomain_augmentedwithoracle[nbetats] =0
        nbmax_added_transition[nbetats] =0
        nbrepaired_generatedFsm[nbetats] = 0
        nbmax_nboutputsequencequery[nbetats] = 0
        maxlengthoutputsequencequery[nbetats] = 0
        nbfaultygeneratedSpec[nbetats] =0
        for id_oracle in range(1,2):
            name = "oracle_"+str(nbetats)+"_"+str(id_oracle)
            oracle = methods.generateoracle(ia,oa,nbetats=nbetats, nom=name)
            #oracle = runningexample.build_oracle()
            methods.saveoracle(oracle, DossierOracle)
            #affichage.show_mealy_machine(oracle)
            #genere sa description
            description = methods.descriptionfororacle(oracle)
            methods.savedescription(description, oracle, DossierDescription)
            #construire le prompt initial
            user_prompt = makeprompts.make_description_prompt(description)
            #creer la session gpt
            gptsession = gptsession.SessionLLM()
            #generer le modèle initial
            responsellm = gptsession.query(user_prompt)
            methods.saveoutputllm(responsellm, oracle, DossierOutputllm)
            #parser le modèle généré
            generatedspec =  methods.parseoutputllm(responsellm,oracle)
            #generatedspec = runningexample.build_generated()
            methods.savegeneratedspec(generatedspec,DossierGeneratedSpec)
            #evaluer la différence entre les modèles
            difftransitions = methods.syntacticequivalence(oracle,generatedspec)
            #mise a jour des statistiques sur les fautes
            methods.updatestats(difftransitions)
            methods.savestats(nbetats,id_oracle, DossierOutputllm)
            methods.savedifftransitions(difftransitions,oracle,generatedspec,DossierDiffTransitions)
            #affichage.show_mealy_machine(generatedspec)
            missingtroninput = generatedspec.isComplete()
            isSyntaxfaulty= difftransitions["are_different"]==1
            generatedspeccompleted= generatedspec
            if len(missingtroninput.keys())>0 :
                print("modèle généré incomplet, on complète avec les self loops")
                generatedspeccompleted= generatedspec.buildComplete()
                #affichage.show_mealy_machine(generatedspeccompleted)
                #methods.savegeneratedspec(generatedspeccompleted,DossierGeneratedSpec)
                isSyntaxfaulty = True
            dseq, product = methods.behaviorequivalence(oracle,generatedspeccompleted)
            #methods.saveproduct(product,DossierProduct)
            #affichage.show_mealy_machine(product)
            isSemanticsfaulty= len(dseq)>0
            if isSemanticsfaulty or isSyntaxfaulty:
                nbfaultygeneratedSpec[nbetats] = nbfaultygeneratedSpec[nbetats] + 1
                extractedFsm, testsuite, addtransitions, repairdomain = methods.faultbasedrepair(oracle, generatedspec, difftransitions, product, gptsession)
                methods.saveoracle(extractedFsm,DossierOracle)
                #affichage.show_mealy_machine(repairdomain)
                if (len(addtransitions)>0) :
                    nbrepairdomain_augmentedwithoracle[nbetats]+=1
                    nbmax_added_transition[nbetats] = max(nbmax_added_transition[nbetats], len(addtransitions) )
                if extractedFsm!=None :
                    extractedFsm.set_name("extracted-"+extractedFsm.get_name())
                    dseqnew, productfinal = methods.behaviorequivalence(oracle,extractedFsm)
                    if len(dseqnew)<=0:
                        nbrepaired_generatedFsm[nbetats] +=1
                    #affichage.show_mealy_machine(productfinal)
                    #affichage.show_mealy_machine(extractedFsm)
                if len(testsuite)>0 :
                    nbmax_nboutputsequencequery[nbetats]= max(nbmax_nboutputsequencequery[nbetats],len(testsuite))
                    element = [len(seq) for seq in testsuite]
                    element.append(maxlengthoutputsequencequery[nbetats])
                    maxlengthoutputsequencequery[nbetats]= max(element)
                    #print(testsuite)
            print("***** log start ********")
            print(f"nbetat, id_oracle,{nbetats}, {id_oracle}")
            print(f"nb repair domains, we were force to add the oracle", nbrepairdomain_augmentedwithoracle[nbetats])
            print(f"nb max of added transitions from the oracle",nbmax_added_transition[nbetats])
            print(f"nb repaired", nbrepaired_generatedFsm[nbetats])
            print(f"nbmax output query to expert", nbmax_nboutputsequencequery[nbetats])
            print(f"max length of queries", maxlengthoutputsequencequery[nbetats])
            print(f"nb faulty generated spec", nbfaultygeneratedSpec[nbetats])
            print(f"***** log end ********")
            fichier = open(DossierStats +"stats.txt", "a+")
            fichier.write(f"***** log start ********\n")
            fichier.write(f"nbetat, id_oracle, {nbetats}, {id_oracle} \n")
            fichier.write(f"nb repair domains, we were force to add the oracle, {nbrepairdomain_augmentedwithoracle[nbetats]}\n")
            fichier.write(f"nb max of added transitions from the oracle, {nbmax_added_transition[nbetats]}\n")
            fichier.write(f"nb repaired, {nbrepaired_generatedFsm[nbetats]}\n")
            fichier.write(f"nbmax output query to expert, {nbmax_nboutputsequencequery[nbetats]}\n")
            fichier.write(f"max length of queries, {maxlengthoutputsequencequery[nbetats]}\n")
            fichier.write(f"nb faulty generated spec, {nbfaultygeneratedSpec[nbetats]}\n")
            fichier.write(f"***** log end ********\n")
            fichier.close()



